# train_model.py

import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score
import joblib


df = pd.read_csv('data/HDHI Admission data.csv')


df_filtered = df[['AGE', 'GENDER', 'RURAL', 'TYPE OF ADMISSION-EMERGENCY/OPD', 'DURATION OF STAY', 'OUTCOME', 'HEART FAILURE']]


df_filtered['GENDER'] = df_filtered['GENDER'].map({'M': 1, 'F': 0})
df_filtered['RURAL'] = df_filtered['RURAL'].map({'R': 1, 'U': 0})
df_filtered['TYPE OF ADMISSION-EMERGENCY/OPD'] = df_filtered['TYPE OF ADMISSION-EMERGENCY/OPD'].map({'E': 1, 'O': 0})

X = df_filtered[['AGE', 'GENDER', 'RURAL', 'TYPE OF ADMISSION-EMERGENCY/OPD', 'DURATION OF STAY']]
y = df_filtered['HEART FAILURE']


X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.3, random_state=42)


model = RandomForestClassifier()
model.fit(X_train, y_train)

y_pred = model.predict(X_test)
accuracy = accuracy_score(y_test, y_pred)
print(f'Model Accuracy: {accuracy * 100:.2f}%')


joblib.dump(model, 'model/model.pkl')

from flask import Flask, render_template, request
import pandas as pd
import joblib
import plotly.express as px
import plotly.graph_objects as go

app = Flask(__name__)


model = joblib.load('model/model.pkl')


def load_and_preprocess_data():
    df = pd.read_csv('data/HDHI Admission data.csv')
    df_filtered = df[['AGE', 'GENDER', 'RURAL', 'TYPE OF ADMISSION-EMERGENCY/OPD', 
                      'DURATION OF STAY', 'OUTCOME', 'HEART FAILURE']]
    return df, df_filtered


@app.route('/')
def dashboard():
    df, df_filtered = load_and_preprocess_data()

  
    age_variation = px.histogram(df_filtered, x="AGE", title="Age Variation", color_discrete_sequence=["#FF5733"])

   
    gender_dist = px.bar(df_filtered, x="GENDER", title="Gender Distribution", 
                         color_discrete_sequence=["#1f77b4", "#d62728"])
    gender_dist.update_traces(marker=dict(line=dict(width=2, color='black')))

    pop_dist = px.pie(df_filtered, names='RURAL', title="Population Distribution (Rural/Urban)", 
                      color_discrete_sequence=["#FF33FF", "#33C1FF"])

   
    avg_duration_age = df_filtered.groupby('AGE', as_index=False)['DURATION OF STAY'].mean()
    avg_duration_age_chart = px.line(avg_duration_age, x="AGE", y="DURATION OF STAY", 
                                      title="Average Duration of Stay by Age", 
                                      labels={"AGE": "Age", "DURATION OF STAY": "Average Duration of Stay"},
                                      color_discrete_sequence=["#FFBB33"])

    
    admission_type = df_filtered['TYPE OF ADMISSION-EMERGENCY/OPD'].value_counts()
    emergency_freq = go.Figure(data=[go.Pie(labels=admission_type.index, values=admission_type.values, hole=.5)])
    emergency_freq.update_traces(marker=dict(colors=['#FF5733', '#C70039']))

    
    median_age_outcome = df_filtered.groupby('OUTCOME', as_index=False)['AGE'].median()
    outcome_age_chart = px.area(median_age_outcome, x="OUTCOME", y="AGE", 
                                 title="Median Age vs Final Status", 
                                 labels={"OUTCOME": "Outcome", "AGE": "Median of AGE"},
                                 color_discrete_sequence=["#FFAA33"],  
                                 category_orders={"OUTCOME": ["EXPIRY", "DAMA", "DISCHARGE"]})
    outcome_age_chart.update_traces(line=dict(color="#FF5733", width=3),  
                                     fillcolor="rgba(255, 165, 0, 0.5)")
    outcome_age_chart.update_yaxes(range=[62, 65])

    
    heart_failure_count = df_filtered['HEART FAILURE'].value_counts().reset_index()
    heart_failure_count.columns = ['HEART FAILURE', 'count']
    heart_failure_chart = px.bar(heart_failure_count, x="count", y="HEART FAILURE", 
                                  title="Count of Heart Failure", 
                                  labels={"HEART FAILURE": "Heart Failure (0 or 1)", "count": "Count of Heart Failure"},
                                  orientation='h',  
                                  color_discrete_sequence=["#FF33FF"])  

    
    df_final_status = df_filtered['OUTCOME'].value_counts().reset_index()
    df_final_status.columns = ['OUTCOME', 'count']
    final_status = px.bar(df_final_status, x='OUTCOME', y='count',
                           title="Final Status Distribution",
                           labels={'OUTCOME': 'Outcome', 'count': 'Count'},
                           color='OUTCOME', color_discrete_sequence=px.colors.qualitative.Pastel)

    
    return render_template('dashboard.html',
                           age_variation=age_variation.to_html(), 
                           gender_dist=gender_dist.to_html(),
                           pop_dist=pop_dist.to_html(),
                           avg_duration_age=avg_duration_age_chart.to_html(),
                           emergency_freq=emergency_freq.to_html(),
                           outcome_age=outcome_age_chart.to_html(),
                           heart_failure=heart_failure_chart.to_html(),
                           final_status=final_status.to_html())


@app.route('/predict', methods=['POST'])
def predict():
    if request.method == 'POST':
        
        age = int(request.form['age'])
        gender = request.form['gender'] 
        rural = request.form['rural']  
        admission_type = request.form['admission'] 
        duration_of_stay = int(request.form['duration'])

        
        gender_num = 1 if gender == 'M' else 0  
        rural_num = 1 if rural == 'R' else 0 
        admission_type_num = 1 if admission_type == 'E' else 0  

        input_data = pd.DataFrame([[age, gender_num, rural_num, admission_type_num, duration_of_stay]], 
                                   columns=['AGE', 'GENDER', 'RURAL', 
                                            'TYPE OF ADMISSION-EMERGENCY/OPD', 'DURATION OF STAY'])

        
        prediction = model.predict(input_data)
        result = 'Heart Disease Detected' if prediction[0] == 1 else 'No Heart Disease'

        
        new_row = {
            'SNO': 0,
            'MRD No.': 0,  
            'D.O.A': '0',  
            'D.O.D': '0',  
            'AGE': age,
            'GENDER': gender, 
            'RURAL': rural, 
            'TYPE OF ADMISSION-EMERGENCY/OPD': admission_type,  
            'month year': '', 
            'DURATION OF STAY': duration_of_stay,
            **{col: 0 for col in ['duration of intensive unit stay', 'OUTCOME', 'SMOKING', 'ALCOHOL', 
                                  'DM', 'HTN', 'CAD', 'PRIOR CMP', 'CKD', 'HB', 'TLC', 
                                  'PLATELETS', 'GLUCOSE', 'UREA', 'CREATININE', 'BNP', 
                                  'RAISED CARDIAC ENZYMES', 'EF', 'SEVERE ANAEMIA', 
                                  'ANAEMIA', 'STABLE ANGINA', 'ACS', 'STEMI', 
                                  'ATYPICAL CHEST PAIN', 'HEART FAILURE', 'HFREF', 
                                  'HFNEF', 'VALVULAR', 'CHB', 'SSS', 'AKI', 
                                  'CVA INFRACT', 'CVA BLEED', 'AF', 'VT', 
                                  'PSVT', 'CONGENITAL', 'UTI', 
                                  'NEURO CARDIOGENIC SYNCOPE', 'ORTHOSTATIC', 
                                  'INFECTIVE ENDOCARDITIS', 'DVT', 
                                  'CARDIOGENIC SHOCK', 'SHOCK', 
                                  'PULMONARY EMBOLISM', 'CHEST INFECTION']},
                                  'OUTCOME': '', 
                                  }
        

        df_new = pd.DataFrame([new_row])
        df_new.to_csv('data/HDHI Admission data.csv', mode='a', header=False, index=False)

       
        return render_dashboard_with_prediction(result)

def render_dashboard_with_prediction(prediction):
    df, df_filtered = load_and_preprocess_data()

   
    age_variation = px.histogram(df_filtered, x="AGE", title="Age Variation", color_discrete_sequence=["#FF5733"])
    gender_dist = px.bar(df_filtered, x="GENDER", title="Gender Distribution", 
                         color_discrete_sequence=["#1f77b4", "#d62728"])
    gender_dist.update_traces(marker=dict(line=dict(width=2, color='black')))
    pop_dist = px.pie(df_filtered, names='RURAL', title="Population Distribution (Rural/Urban)", 
                      color_discrete_sequence=["#FF33FF", "#33C1FF"])
    avg_duration_age = df_filtered.groupby('AGE', as_index=False)['DURATION OF STAY'].mean()
    avg_duration_age_chart = px.line(avg_duration_age, x="AGE", y="DURATION OF STAY", 
                                      title="Average Duration of Stay by Age", 
                                      labels={"AGE": "Age", "DURATION OF STAY": "Average Duration of Stay"},
                                      color_discrete_sequence=["#FFBB33"])
    admission_type = df_filtered['TYPE OF ADMISSION-EMERGENCY/OPD'].value_counts()
    emergency_freq = go.Figure(data=[go.Pie(labels=admission_type.index, values=admission_type.values, hole=.5)])
    emergency_freq.update_traces(marker=dict(colors=['#FF5733', '#C70039']))
    median_age_outcome = df_filtered.groupby('OUTCOME', as_index=False)['AGE'].median()
    outcome_age_chart = px.area(median_age_outcome, x="OUTCOME", y="AGE", 
                                 title="Median Age vs Final Status", 
                                 labels={"OUTCOME": "Outcome", "AGE": "Median of AGE"},
                                 color_discrete_sequence=["#FFAA33"],  
                                 category_orders={"OUTCOME": ["EXPIRY", "DAMA", "DISCHARGE"]})
    outcome_age_chart.update_traces(line=dict(color="#FF5733", width=3),  
                                     fillcolor="rgba(255, 165, 0, 0.5)")
    outcome_age_chart.update_yaxes(range=[62, 65])
    heart_failure_count = df_filtered['HEART FAILURE'].value_counts().reset_index()
    heart_failure_count.columns = ['HEART FAILURE', 'count']
    heart_failure_chart = px.bar(heart_failure_count, x="count", y="HEART FAILURE", 
                                  title="Count of Heart Failure", 
                                  labels={"HEART FAILURE": "Heart Failure (0 or 1)", "count": "Count"},
                                  orientation='h',  
                                  color_discrete_sequence=["#FF33FF"])  
    df_final_status = df_filtered['OUTCOME'].value_counts().reset_index()
    df_final_status.columns = ['OUTCOME', 'count']
    final_status = px.bar(df_final_status, x='OUTCOME', y='count',
                           title="Final Status Distribution",
                           labels={'OUTCOME': 'Outcome', 'count': 'Count'},
                           color='OUTCOME', color_discrete_sequence=px.colors.qualitative.Pastel)


    return render_template('dashboard.html',
                           age_variation=age_variation.to_html(), 
                           gender_dist=gender_dist.to_html(),
                           pop_dist=pop_dist.to_html(),
                           avg_duration_age=avg_duration_age_chart.to_html(),
                           emergency_freq=emergency_freq.to_html(),
                           outcome_age=outcome_age_chart.to_html(),
                           heart_failure=heart_failure_chart.to_html(),
                           final_status=final_status.to_html(),
                           prediction=prediction)

if __name__ == '__main__':
    app.run(debug=True)
